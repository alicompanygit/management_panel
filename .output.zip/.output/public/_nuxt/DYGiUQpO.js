import{p as t}from"#entry";const o=t({tag:{type:String,default:"div"}},"tag");export{o as m};
//# sourceMappingURL=DYGiUQpO.js.map
