import{s,o as t,d as e,bK as n}from"#entry";function i(){const o=s(!1);return t(()=>{window.requestAnimationFrame(()=>{o.value=!0})}),{ssrBootStyles:e(()=>o.value?void 0:{transition:"none !important"}),isBooted:n(o)}}export{i as u};
//# sourceMappingURL=CPNFP-7W.js.map
